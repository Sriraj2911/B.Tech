#ifndef DATAOP_H
#define DATAOP_H

void sort_array(int *arr, int size);
int find_max(int *arr, int size);

#endif // DATAOP_H
