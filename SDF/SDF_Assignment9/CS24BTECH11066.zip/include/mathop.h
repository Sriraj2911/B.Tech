#ifndef MATHOP_H
#define MATHOP_H

int add(int a, int b);
int subtract(int a, int b);

#endif // MATHOP_H
