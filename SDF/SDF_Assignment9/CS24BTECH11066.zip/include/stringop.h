#ifndef STRINGOP_H
#define STRINGOP_H

void to_uppercase(char *str);
void to_lowercase(char *str);

#endif // STRINGOP_H
